<footer>
    <div class="container foot1">
  <a href="https://accounts.google.com/signin/v2/sl/pwd?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin"><input type="submit" class="Email" name="" value="Email"></a>      	
        <a href="about.php"><input type="submit" class="About" name="about" value="About"></a>
        <a href="terms.php"><input type="submit" class="Terms" name="terms" value="Terms"></a>
    </div>
</footer>


<!--<div class="foot1">
	<a href="about.php"><input type="submit" class="About" name="about" value="About"></a>
        <a href="terms.php"><input type="submit" class="Terms" name="terms" value="Terms"></a>
</div> -->
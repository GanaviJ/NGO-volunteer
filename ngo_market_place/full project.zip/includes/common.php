<?php
$con = mysqli_connect("localhost", "root", "", "ngo_marketplace")or die($mysqli_error($con));
session_start();
?>
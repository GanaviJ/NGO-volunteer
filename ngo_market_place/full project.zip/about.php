<?php
require("includes/common.php");
?>
<!DOCTYPE html>
<html>
<head>
	
    <title>terms</title>
    <link rel="stylesheet" type="text/css" href="about.css">
</head>
<body>
	<?php
        include 'includes/header.php';
        ?>
   <div class="about">
   		<h1>ABOUT</h1>
   		<p></p>
   	</div>
	
     <?php
        include 'includes/footer.php';
        ?>
</body>

</html>